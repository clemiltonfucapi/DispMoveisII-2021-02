# FirebaseApp
README.md é feito em **Markdown**
## Comandos git
- ``git clone <url>``: clona(baixa) o repositorio para maquina local
- ``git add --all``: adiciona todos os arquivos/pastas no próx commit
- ``git commit -m "Mensagem commit"``: Realiza o commit no repositorio local
- ``git push -u origin main``: "Empurra" os commit's para o repositorio remoto
- ``git pull``: "Puxa" as alterações feitas no repositorio remoto -> Local (git fetch + git merge)
